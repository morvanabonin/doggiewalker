!function($){
	"use strict";
        
    $('.carousel').carousel({
        interval: 7000
    })
    
    $(document).ready(function() {
        $('#telefone').mask("(99) 9999-9999");
    });

    $('.enviar').click(function(){    
    var nome = $("#nome").val();
    var telefone  = $("#telefone").val();
    var email  = $("#email").val();
    var mensagem = $("#mensagem").val();
    if ((nome != "" && email != "" && mensagem != "")) {
                var data = {
                    "acao"       : "enviar",
                    "nome"       : nome,
                    "telefone"   : telefone,
                    "email"      : email,
                    "mensagem"   : mensagem
                };
            $('#load').show();
            $.ajax({
              url:'mail/controller.php',
              async:true,
              complete: function(json) {
                  var result = eval('(' + json.responseText + ')');
                  alert(result);
                  if(result == true) {
                      $('#load').hide();
                      alert('Mensagem enviada com sucesso!');
                  } else {
                      $('#load').hide();
                      alert('Ocorreu um erro ao enviar a mensagem!');
                  }
              },
            cache:false,
            type:'POST',
            data:data
        });
    } else {
        alert('Verifique os campos mandatorios');
    }
});

$('.limpar').click(function(){
    $("#nome").val('');
    $("#telefone").val('');
    $("#email").val('');
    $("#mensagem").val('');

});
        
}(window.jQuery);