<?php
    require_once 'Mail.php';

    if (!empty($_POST['nome'])) {
    //switch ($_POST['acao']) {
        //case ('enviar'):
            try {
                $cad = new Mail();
                $nome = $_POST['nome'];
                $telefone = $_POST['telefone'];
                $email = $_POST['email'];
                $mensagem = $_POST['mensagem'];
                echo json_encode($cad->sendMail($nome, $telefone, $email, $mensagem));
            } catch (exception $e) {
                throw ($e);
            }
        //}
    }
?>
